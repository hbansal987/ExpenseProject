package com.example.himanshubansal.expenseproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME= "Information.db";
    public static final String TABLE_NAME= "Information_Table";
    public static final String COL_DATE= "Date";
    public static final String COL_SOURCE= "Source";
    public static final String COL_AMOUNT= "Amount";
    public static final String COL_TYPE= "Type";

    public ArrayList<Information> infoList= new ArrayList<Information>();

    SQLiteDatabase db;


    public DatabaseHelper(Context context) {
        super(context,DATABASE_NAME, null, 1);
        SQLiteDatabase db= this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table "+ TABLE_NAME+ "( "+COL_DATE+ " STRING,"+COL_SOURCE+ " STRING,"
                +COL_AMOUNT+ " STRING,"+COL_TYPE+ " STRING);" );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void storeInformation(String date, String source, String amount,String type){
        SQLiteDatabase db= this.getWritableDatabase();
        ContentValues contentValues= new ContentValues();
        contentValues.put(COL_DATE,date);
        contentValues.put(COL_SOURCE,source);
        contentValues.put(COL_AMOUNT,amount);
        contentValues.put(COL_TYPE,type);

        db.insert(TABLE_NAME,null,contentValues);
        db.close();
    }

    public ArrayList<Information> queryDBList(String dated){
        try {
            db = this.getReadableDatabase();
            String query_params = "SELECT * FROM " + TABLE_NAME;
            Cursor cSor = db.rawQuery(query_params, null);
            if (cSor.moveToFirst()) {
                do {

                   // int id = cSor.getInt(cSor.getColumnIndexOrThrow(COL_ID));
                    String date = cSor.getString(cSor.getColumnIndexOrThrow(COL_DATE));
                    String source = cSor.getString(cSor.getColumnIndexOrThrow(COL_SOURCE));
                    String amount = cSor.getString(cSor.getColumnIndexOrThrow(COL_AMOUNT));
                    String type = cSor.getString(cSor.getColumnIndexOrThrow(COL_TYPE));

                    if(dated.equals(date)) {
                        infoList.add(new Information(date, source, amount, type));
                    }
                }
                while (cSor.moveToNext());
                {

                }
            } else {
                return null;
            }


        }catch (Exception e){
            e.printStackTrace();
        }
        db.close();
        return infoList;
    }

    public Boolean checkifidExists(int _id){
        int storeId= -1090;
        SQLiteDatabase db = this.getReadableDatabase();
        String query_params = "SELECT * FROM " + TABLE_NAME + " WHERE SongId = '$_id'";
        Cursor cSor = db.rawQuery(query_params, null);
        if(cSor.moveToFirst()){
            do{
                //storeId= cSor.getInt(cSor.getColumnIndexOrThrow(COL_ID));

            }while(cSor.moveToNext());
        }
        else{
            return false;
        }
        return storeId!= -1090;
    }
}
