package com.example.himanshubansal.expenseproject.Activities;

import android.app.Dialog;
import android.icu.text.IDNA;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.himanshubansal.expenseproject.Adapters.ExpenseAdapter;
import com.example.himanshubansal.expenseproject.Information;
import com.example.himanshubansal.expenseproject.R;

import java.util.ArrayList;

public class ExpenseManagement extends AppCompatActivity {

    private RecyclerView mRecyclerView;
    private ExpenseAdapter mExpenseAdapter;
    ArrayList<Information> infoList= new ArrayList<Information>();

    Button addMoney;
    Button takeMoney;
    Button submit;
    TextView walletExpense;
    EditText SourceName;
    EditText money;
    Dialog dialog= null;
    String date;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expense_management);

        addMoney= findViewById(R.id.addMoney);
        takeMoney= findViewById(R.id.takeMoney);
        walletExpense= findViewById(R.id.walletTextExpense);

        walletExpense.setText("Wallet: "+ MainActivity.wallet);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            date = extras.getString("Date");
        }

        if(MainActivity.mainList.get(date)!= null){
            infoList= MainActivity.mainList.get(date);
        };

        Recycle();

        addMoney.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialog();

                submit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        MainActivity.wallet= MainActivity.wallet+ Integer.parseInt(money.getText().toString());
                        dialog.cancel();
                        walletExpense.setText("Wallet: "+ MainActivity.wallet);

                        Information inform= new Information(date,SourceName.getText().toString(),money.getText().toString(),"ADD");
                        infoList.add(inform);
                        Recycle();
                    }
                });
            }
        });



        takeMoney.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialog();

                submit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        MainActivity.wallet= MainActivity.wallet - Integer.parseInt(money.getText().toString());
                        dialog.cancel();
                        walletExpense.setText("Wallet: "+ MainActivity.wallet);
                        Information inform= new Information(date,SourceName.getText().toString(),money.getText().toString(),"TAKE");
                        infoList.add(inform);
                        Recycle();
                    }
                });
            }
        });

        MainActivity.mainList.put(date,infoList);

    }

    public void Recycle(){
        mRecyclerView= (RecyclerView) findViewById(R.id.ExpenseList);
        mExpenseAdapter= new ExpenseAdapter(getApplicationContext(),infoList);
        mRecyclerView.setAdapter(mExpenseAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
    }

    public void openDialog() {
        dialog = new Dialog(this); // Context, this, etc.
        dialog.setContentView(R.layout.dialogbox);
        dialog.setTitle("Please Enter Information");
        submit=dialog.findViewById(R.id.submitButton);
        SourceName= dialog.findViewById(R.id.enterSource);
        money= dialog.findViewById(R.id.enterAmount);

        dialog.show();
    }
}
