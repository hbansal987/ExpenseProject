package com.example.himanshubansal.expenseproject.Adapters;

import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.himanshubansal.expenseproject.Information;
import com.example.himanshubansal.expenseproject.R;

import java.util.ArrayList;

public class ExpenseAdapter extends RecyclerView.Adapter {

    Context mContext;
    ArrayList<Information> informationList;

    public ExpenseAdapter(Context mContext, ArrayList<Information> informationList) {
        this.mContext = mContext;
        this.informationList = informationList;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view;

        view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.expenseadapter, viewGroup, false);
        return new MyViewHolder(view);


    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {

        Information information=null;
        information= informationList.get(i);
        ((MyViewHolder) viewHolder).bind(information);
    }

    @Override
    public int getItemCount() {
        return informationList.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder{

        TextView sourceTextInfo,amountTextInfo;
        RelativeLayout contentHolder;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            sourceTextInfo= itemView.findViewById(R.id.sourceText);
            amountTextInfo= itemView.findViewById(R.id.amountText);
            contentHolder= itemView.findViewById(R.id.expenseLayout);
        }

        //Now the information has come to the holder.

        public void bind(Information info){

            sourceTextInfo.setText("Source: "+info.getSource());
            amountTextInfo.setText("Amount: "+info.getAmount());

            if(info.getType()=="ADD"){
                sourceTextInfo.setTextColor(Color.parseColor("#008000"));
                amountTextInfo.setTextColor(Color.parseColor("#008000"));
            }
            else{
                sourceTextInfo.setTextColor(Color.parseColor("#FF0000"));
                amountTextInfo.setTextColor(Color.parseColor("#FF0000"));
            }
        }

    }
}
