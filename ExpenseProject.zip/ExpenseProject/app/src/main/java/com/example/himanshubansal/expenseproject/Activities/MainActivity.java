package com.example.himanshubansal.expenseproject.Activities;

import android.content.Intent;
import android.icu.text.IDNA;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.CalendarView;
import android.widget.TextView;

import com.example.himanshubansal.expenseproject.DatabaseHelper;
import com.example.himanshubansal.expenseproject.Information;
import com.example.himanshubansal.expenseproject.R;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    CalendarView calendar= null;
    TextView walletText= null;
    public static int wallet=0;
    public static HashMap<String,ArrayList<Information>> mainList = new HashMap<String, ArrayList<Information>>();

    DatabaseHelper myDb;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myDb= new DatabaseHelper(this);
        calendar = (CalendarView) findViewById(R.id.calender);
        walletText= (TextView) findViewById (R.id.walletText);

        walletText.setText("Wallet: "+ wallet);

        calendar.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
                Intent i= new Intent(MainActivity.this,ExpenseManagement.class);
                i.putExtra("Date",dayOfMonth+"/"+month+"/"+year);
                startActivity(i);
                walletText.setText("Wallet: "+ wallet);
            }
        });

        walletText.setText("Wallet: "+ wallet);
    }
}
